# agenda-visitas-aa — PWA corrigida

Arquivos:
- index.html
- manifest.json
- sw.js

O index.html original foi preservado e recebeu apenas a camada PWA:
- manifest link
- registro do Service Worker
- botão de instalação
- beforeinstallprompt
- appinstalled
- detecção de standalone

O cache do Service Worker foi atualizado para v2.

IMPORTANTE:
1. Publique estes arquivos na raiz do site Netlify.
2. Os arquivos icon-192.png e icon-512.png precisam existir na raiz se forem usados pelo manifest.
3. Depois de publicar, abra o site no Chrome Android e recarregue.
4. Se o Chrome ainda estiver com uma instalação antiga, desinstale o ícone antigo pela tela de aplicativos do Android e abra novamente o endereço no Chrome.
