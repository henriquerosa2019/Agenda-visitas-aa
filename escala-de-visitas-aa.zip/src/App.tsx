import React, { useState, useEffect } from 'react';
import {
  AgendaData,
  VisitItem,
  sortVisitsAscending,
  getWeekdayName,
  getVisitStatus,
  formatFullDateBr,
  formatTimeBr,
} from './types';
import { INITIAL_AGENDA } from './data/initialData';
import { AALogo } from './components/AALogo';
import { EditVisitModal } from './components/EditVisitModal';
import { VisitSummaryModal } from './components/VisitSummaryModal';
import { getSupabaseClient } from './lib/supabase';
import { FileText, CheckCircle2, MessageSquareText, Calendar } from 'lucide-react';

const CURRENT_STORAGE_KEY = 'escala_visitas_aa_data_v8';

export default function App() {
  const [state, setState] = useState<AgendaData>(() => {
    // Limpeza de chaves antigas de teste do navegador
    try {
      localStorage.removeItem('escala_visitas_aa_data_v5');
      localStorage.removeItem('escala_visitas_aa_data_v6');
      localStorage.removeItem('escala_visitas_aa_data_v7');
    } catch (e) {}

    try {
      const saved = localStorage.getItem(CURRENT_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.visits) && parsed.visits.length > 0) {
          // Garante que a Clínica da Gávea ou qualquer visita sem confirmação venha limpa
          const cleanedVisits = parsed.visits.map((v: VisitItem) => {
            if (v.id === 'sept-14-10h' || v.name.toLowerCase().includes('gávea')) {
              return {
                ...v,
                visitSummary: undefined,
                completedBy: undefined,
                completedAt: undefined,
                isCompleted: false,
              };
            }
            return v;
          });
          return {
            groupName: parsed.groupName || INITIAL_AGENDA.groupName,
            objective: parsed.objective || INITIAL_AGENDA.objective,
            visits: sortVisitsAscending(cleanedVisits),
          };
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_AGENDA;
  });

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [selectedVisit, setSelectedVisit] = useState<VisitItem | null>(null);

  // Modal de Resumo da Visita
  const [summaryModalOpen, setSummaryModalOpen] = useState<boolean>(false);
  const [summaryVisit, setSummaryVisit] = useState<VisitItem | null>(null);

  // Salvar no LocalStorage e sincronizar
  useEffect(() => {
    try {
      localStorage.setItem(CURRENT_STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error(e);
    }
  }, [state]);

  const sortedVisits = sortVisitsAscending(state.visits);

  const toggleEdit = () => {
    setIsEditing((prev) => !prev);
  };

  const handleOpenNewVenue = () => {
    setSelectedVisit(null);
    setModalOpen(true);
  };

  const handleEditVenue = (visit: VisitItem) => {
    setSelectedVisit(visit);
    setModalOpen(true);
  };

  const handleOpenSummary = (visit: VisitItem) => {
    setSummaryVisit(visit);
    setSummaryModalOpen(true);
  };

  const handleSaveModalVisit = (visit: VisitItem) => {
    setState((prev) => {
      const exists = prev.visits.some((v) => v.id === visit.id);
      let updated: VisitItem[];
      if (exists) {
        updated = prev.visits.map((v) => (v.id === visit.id ? visit : v));
      } else {
        updated = [...prev.visits, visit];
      }
      return {
        ...prev,
        visits: sortVisitsAscending(updated),
      };
    });
  };

  const handleSaveVisitSummary = (
    visitId: string,
    summary: string,
    completedBy: string,
    isCompleted: boolean
  ) => {
    const completedAt = new Date().toISOString();

    setState((prev) => ({
      ...prev,
      visits: prev.visits.map((v) => {
        if (v.id !== visitId) return v;
        return {
          ...v,
          visitSummary: summary ? summary : undefined,
          completedBy: undefined,
          completedAt: summary ? completedAt : undefined,
          isCompleted: isCompleted ? true : false,
        };
      }),
    }));

    // Tentar salvar no Supabase se houver conexão configurada
    const client = getSupabaseClient();
    if (client) {
      const targetVisit = state.visits.find((v) => v.id === visitId);
      if (targetVisit) {
        client
          .from('aa_visits')
          .upsert({
            id: visitId,
            name: targetVisit.name,
            addr: targetVisit.addr,
            date: targetVisit.date,
            time: targetVisit.time,
            slots: targetVisit.slots,
            notes: targetVisit.notes || null,
            visit_summary: summary || null,
            completed_by: null,
            completed_at: summary ? completedAt : null,
          })
          .then(() => {});
      }
    }
  };

  const handleRemoveVisit = (id: string, name: string) => {
    if (!confirm(`Remover "${name}" e sua visita da agenda?`)) return;
    setState((prev) => ({
      ...prev,
      visits: prev.visits.filter((v) => v.id !== id),
    }));
  };

  const handleDateChange = (id: string, newDate: string) => {
    setState((prev) => ({
      ...prev,
      visits: sortVisitsAscending(
        prev.visits.map((v) => (v.id === id ? { ...v, date: newDate } : v))
      ),
    }));
  };

  const handleTimeChange = (id: string, newTime: string) => {
    setState((prev) => ({
      ...prev,
      visits: sortVisitsAscending(
        prev.visits.map((v) => (v.id === id ? { ...v, time: newTime } : v))
      ),
    }));
  };

  const handleSlotChange = (visitId: string, slotIdx: number, val: string) => {
    setState((prev) => ({
      ...prev,
      visits: prev.visits.map((v) => {
        if (v.id !== visitId) return v;
        const newSlots = [...v.slots];
        newSlots[slotIdx] = val;
        return { ...v, slots: newSlots };
      }),
    }));
  };

  const handleRemoveSlot = (visitId: string, slotIdx: number) => {
    setState((prev) => ({
      ...prev,
      visits: prev.visits.map((v) => {
        if (v.id !== visitId) return v;
        const newSlots = v.slots.filter((_, i) => i !== slotIdx);
        return { ...v, slots: newSlots };
      }),
    }));
  };

  const handleAddSlot = (visitId: string) => {
    setState((prev) => ({
      ...prev,
      visits: prev.visits.map((v) => {
        if (v.id !== visitId) return v;
        return { ...v, slots: [...v.slots, ''] };
      }),
    }));
  };

  return (
    <div className="min-h-screen bg-[#123C6B] text-[#1E2A3F] font-sans py-12 px-4 sm:px-6">
      {/* Botão Superior Direito */}
      <div className="fixed top-4 right-4 z-30">
        <button
          onClick={toggleEdit}
          id="editBtn"
          className="font-mono text-xs uppercase tracking-wider font-semibold px-4 py-2.5 rounded-full border border-[#8A6A38] bg-gradient-to-br from-[#E4C687] to-[#C7A25C] text-[#2A1F0A] shadow-lg hover:brightness-105 transition-all cursor-pointer"
        >
          {isEditing ? '💾 Salvar' : '✎ Editar agenda'}
        </button>
      </div>

      {/* Sheet Principal - Folha Timbrada */}
      <div className="max-w-[840px] mx-auto bg-[#FBF9F2] rounded-[10px] p-6 sm:p-12 shadow-[0_30px_70px_rgba(6,22,42,0.45)] relative">
        {/* Cabeçalho */}
        <header className="text-center pb-6 border-b-2 border-[#1E2A3F] mb-8 relative">
          <div className="w-36 mx-auto mb-4 flex items-center justify-center">
            <AALogo size={130} />
          </div>

          <h1
            contentEditable={isEditing}
            suppressContentEditableWarning
            onBlur={(e) => {
              const text = e.currentTarget.textContent?.trim();
              if (text) setState((p) => ({ ...p, groupName: text }));
            }}
            className={`font-serif font-bold text-2xl sm:text-4xl text-[#29166F] mb-2 tracking-tight ${
              isEditing ? 'hover:bg-black/5 focus:bg-white rounded px-2 outline-none' : ''
            }`}
          >
            {state.groupName}
          </h1>

          <div className="font-mono text-[11px] tracking-[3px] uppercase text-[#A9834C] mb-2 font-semibold">
            Escala de Serviços
          </div>

          <p
            contentEditable={isEditing}
            suppressContentEditableWarning
            onBlur={(e) => {
              const text = e.currentTarget.textContent?.trim();
              if (text) setState((p) => ({ ...p, objective: text }));
            }}
            className={`font-serif italic font-medium text-sm sm:text-base text-[#4A5568] max-w-[520px] mx-auto leading-relaxed ${
              isEditing ? 'hover:bg-black/5 focus:bg-white rounded px-2 outline-none' : ''
            }`}
          >
            {state.objective}
          </p>
        </header>

        {/* Lista de Locais e Visitas */}
        <main className="space-y-6">
          {sortedVisits.map((visit) => {
            const status = getVisitStatus(visit.date, visit.isCompleted);
            const isPast = status === 'past';

            let nameClasses = 'text-[#29166F]';
            let statusTag = null;

            if (status === 'today') {
              nameClasses = 'text-green-700 font-bold';
              statusTag = (
                <span className="text-[11px] font-mono font-bold text-green-700 bg-green-100/80 px-2 py-0.5 rounded border border-green-300">
                  Hoje
                </span>
              );
            } else if (status === 'tomorrow') {
              nameClasses = 'text-green-700 font-bold';
              statusTag = (
                <span className="text-[11px] font-mono font-bold text-green-700 bg-green-100/80 px-2 py-0.5 rounded border border-green-300">
                  Amanhã
                </span>
              );
            } else if (isPast) {
              nameClasses = 'text-red-700 font-bold line-through decoration-red-600/80 decoration-2';
              statusTag = (
                <span className="text-[11px] font-mono font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded border border-red-300 shadow-2xs">
                  Já ocorreu
                </span>
              );
            }

            const weekday = getWeekdayName(visit.date);

            return (
              <section
                key={visit.id}
                className={`bg-white border rounded-md overflow-hidden shadow-xs hover:shadow-sm transition-all ${
                  isPast
                    ? 'border-red-200 bg-red-50/10'
                    : 'border-[#1E2A3F]/15'
                }`}
              >
                {/* Cabeçalho do Local */}
                <div className="p-5 border-b border-dashed border-[#1E2A3F]/15">
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                    <div className="flex-1">
                      {/* Nome do Local */}
                      <div className="flex items-center flex-wrap gap-2 mb-1">
                        <span className="text-xl select-none leading-none">🏥</span>
                        <h2
                          className={`font-serif font-semibold text-lg sm:text-xl ${nameClasses} transition-all`}
                        >
                          {visit.name}
                        </h2>
                        {statusTag}
                      </div>

                      {/* Endereço */}
                      <div className="flex items-center gap-1.5 font-mono text-xs sm:text-[13px] text-[#4A5568] mt-1.5">
                        <span className="text-sm select-none leading-none">📍</span>
                        <span>{visit.addr}</span>
                      </div>
                    </div>

                    {/* Botões: Resumo + Editar */}
                    <div className="flex items-center flex-wrap gap-2 justify-start sm:justify-end mt-2 sm:mt-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-dashed border-[#1E2A3F]/15">
                      {/* Botão Resumo da Visita */}
                      <button
                        type="button"
                        onClick={() => handleOpenSummary(visit)}
                        className={`text-xs font-mono font-bold px-2.5 py-1.5 rounded-md flex items-center gap-1.5 border transition-all cursor-pointer ${
                          visit.visitSummary
                            ? 'bg-[#DEE9E2] text-[#2B5446] border-[#3E6B5C]/30 hover:bg-[#cde0d3]'
                            : 'bg-[#FBF9F2] text-[#123C6B] border-[#123C6B]/30 hover:bg-[#123C6B] hover:text-white'
                        }`}
                        title="Registrar ou visualizar o resumo de como foi a visita"
                      >
                        {visit.visitSummary ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#3E6B5C]" />
                        ) : (
                          <FileText className="w-3.5 h-3.5 text-[#A9834C]" />
                        )}
                        <span>{visit.visitSummary ? 'Ver Resumo' : '+ Resumo da Visita'}</span>
                      </button>

                      {/* Botão editar todos os dados */}
                      <button
                        type="button"
                        onClick={() => handleEditVenue(visit)}
                        className="text-xs font-mono text-[#123C6B] hover:text-[#1E5A9C] font-semibold underline underline-offset-2 cursor-pointer ml-1"
                        title="Editar todos os dados deste local"
                      >
                        editar dados
                      </button>

                      {isEditing && (
                        <button
                          type="button"
                          onClick={() => handleRemoveVisit(visit.id, visit.name)}
                          className="text-xs font-mono text-red-600 hover:text-red-800 cursor-pointer ml-1"
                          title="Remover este local"
                        >
                          remover
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Linha da Visita (Data, Horário e Vagas) */}
                <div className="flex flex-col sm:flex-row border-b border-dashed border-[#1E2A3F]/15 last:border-b-0">
                  {/* Data e Horário */}
                  <div className="sm:w-[200px] sm:min-w-[200px] p-4 sm:border-r border-dashed border-[#1E2A3F]/15 flex flex-row sm:flex-col justify-center items-start gap-1.5 bg-[#FBF9F2]/30">
                    {isEditing ? (
                      <input
                        type="date"
                        value={visit.date}
                        onChange={(e) => handleDateChange(visit.id, e.target.value)}
                        className="font-mono font-semibold text-sm bg-white border border-[#A9834C]/50 rounded px-2 py-1 text-[#1E2A3F] outline-none w-full cursor-pointer shadow-xs"
                      />
                    ) : (
                      <div className="font-serif font-bold text-lg text-[#1E2A3F] tracking-tight whitespace-nowrap">
                        {formatFullDateBr(visit.date)}
                      </div>
                    )}

                    <div className="font-mono text-[11px] uppercase text-[#4A5568] tracking-wider font-semibold">
                      {weekday}
                    </div>

                    {isEditing ? (
                      <input
                        type="time"
                        value={visit.time}
                        onChange={(e) => handleTimeChange(visit.id, e.target.value)}
                        className="font-mono font-medium text-xs bg-white border border-[#A9834C]/50 rounded px-2 py-1 text-[#A9834C] outline-none w-full cursor-pointer shadow-xs"
                      />
                    ) : (
                      <div className="font-mono font-semibold text-xs sm:text-[13px] text-[#A9834C]">
                        {formatTimeBr(visit.time)}
                      </div>
                    )}
                  </div>

                  {/* Vagas de Companheiro(a)s */}
                  <div className="flex-1 p-3.5 sm:p-4 flex flex-wrap items-center gap-2">
                    {visit.slots.map((name, ni) => {
                      const isOpen = !name || name.trim() === '';
                      return (
                        <div
                          key={ni}
                          className={`flex items-center gap-2 py-1.5 px-2.5 rounded-full text-xs font-medium border ${
                            isOpen
                              ? 'bg-[#F4E2DE] text-[#B23A2E] border-dashed border-[#B23A2E]'
                              : 'bg-[#DEE9E2] text-[#3E6B5C] border-transparent'
                          }`}
                        >
                          <span
                            className={`font-mono text-[10.5px] w-4 h-4 rounded-full text-white flex items-center justify-center flex-shrink-0 ${
                              isOpen ? 'bg-[#B23A2E]' : 'bg-[#3E6B5C]'
                            }`}
                          >
                            {ni + 1}
                          </span>

                          <input
                            type="text"
                            value={name}
                            placeholder="vaga aberta"
                            onChange={(e) => handleSlotChange(visit.id, ni, e.target.value)}
                            className={`bg-transparent outline-none min-w-[100px] sm:min-w-[120px] text-xs ${
                              isOpen ? 'placeholder:text-[#B23A2E] placeholder:italic text-[#B23A2E]' : 'text-[#3E6B5C]'
                            }`}
                          />

                          {isEditing && (
                            <button
                              type="button"
                              onClick={() => handleRemoveSlot(visit.id, ni)}
                              className="text-inherit opacity-60 hover:opacity-100 text-sm leading-none cursor-pointer"
                              title="Remover esta vaga"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      );
                    })}

                    {/* Adicionar Vaga */}
                    <button
                      type="button"
                      onClick={() => handleAddSlot(visit.id)}
                      className="flex items-center gap-1 py-1.5 px-3 rounded-full border border-dashed border-[#C7A25C] text-[#A9834C] font-mono text-xs hover:bg-[#A9834C]/10 cursor-pointer transition-colors"
                      title="Adicionar vaga para voluntário"
                    >
                      + vaga
                    </button>
                  </div>
                </div>

                {/* Resumo da Visita */}
                {visit.visitSummary && (
                  <div className="bg-[#FBF9F2] p-4 border-t border-[#1E2A3F]/10 text-xs">
                    <div className="flex items-center justify-between gap-2 mb-1.5 text-[#123C6B] font-mono font-bold uppercase tracking-wider">
                      <span className="flex items-center gap-1.5">
                        <MessageSquareText className="w-3.5 h-3.5 text-[#A9834C]" />
                        <span>Como foi a visita (servidores, nº de internos; etc):</span>
                      </span>
                    </div>
                    <p className="text-[#1E2A3F] font-serif italic whitespace-pre-wrap leading-relaxed bg-white p-3 rounded border border-[#1E2A3F]/15">
                      "{visit.visitSummary}"
                    </p>
                  </div>
                )}
              </section>
            );
          })}
        </main>

        {/* Botão Novo Local de Visita */}
        <div className="mt-6 mb-8">
          <button
            type="button"
            onClick={handleOpenNewVenue}
            className="flex items-center gap-2 py-2.5 px-4 rounded-full border border-dashed border-[#C7A25C] text-[#A9834C] hover:text-[#8A6A38] font-mono text-xs font-semibold hover:bg-[#A9834C]/10 transition-colors cursor-pointer"
          >
            + novo local de visita
          </button>
        </div>

        {/* Rodapé e Orientações */}
        <footer className="pt-5 border-t border-[#1E2A3F]/15 text-center">
          <p className="font-mono text-[11px] text-[#29166F] font-bold tracking-wide">
            Vagas em aberto são preenchidas por companheiro(a)s voluntários —{' '}
            <u>Confirme e Desmarque sua presença com antecedência</u>.
          </p>

          <div className="font-sans text-xs text-[#4A5568] leading-relaxed mt-3.5 max-w-[540px] mx-auto text-left">
            <p>
              <b>✎ Editar</b> — clique para inserir seu nome nas vagas e ajustar datas/horários. Ao clicar em <b>"editar dados"</b> ou <b>"+ novo local de visita"</b>, abrem-se todos os campos para edição completa.
            </p>
            <p className="mt-1">
              <b>📝 Resumo da Visita:</b> Clique no botão <b>"+ Resumo da Visita"</b> para registrar como foi a experiência e observações.
            </p>
          </div>
        </footer>
      </div>

      {/* Modal para Editar Todos os Dados do Local */}
      <EditVisitModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={handleSaveModalVisit}
        initialVisit={selectedVisit}
      />

      {/* Modal para Resumo da Visita */}
      <VisitSummaryModal
        isOpen={summaryModalOpen}
        onClose={() => setSummaryModalOpen(false)}
        onSaveSummary={handleSaveVisitSummary}
        visit={summaryVisit}
      />
    </div>
  );
}
